import java.io.*;


public class WriterAndReader {
    public String ReadToFile(String nameOfFile) {
        StringBuilder result = new StringBuilder();
        try(FileReader reader = new FileReader(nameOfFile))
        {
            int c;
            while((c=reader.read())!=-1){
                result.append((char)c);
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        return result.toString();
    }

    public void WriteToFile(String nameOfFile, String text) {
        try(FileWriter writer = new FileWriter(nameOfFile, true))
        {
            writer.write(text + "\n");
            writer.flush();
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
}
